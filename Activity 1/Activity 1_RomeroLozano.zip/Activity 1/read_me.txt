in the two text files are the uml
in activity_1_JavaProject->src->worker are my date and employee class
in activity_1_JavaProject->src->App.java is where I test the classes
I have also added a screenshot of the output